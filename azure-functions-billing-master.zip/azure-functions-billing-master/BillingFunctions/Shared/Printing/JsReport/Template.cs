﻿namespace Shared.Printing.JsReport
{
    class Template
    {
        public string Name { get; private set; }

        public Template(string name)
        {
            Name = name;
        }
    }
}
