﻿namespace Shared.Billing
{
    public enum Gender
    {
        Male,
        Female
    }
}
