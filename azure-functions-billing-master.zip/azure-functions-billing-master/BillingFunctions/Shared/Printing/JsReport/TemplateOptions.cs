﻿namespace Shared.Printing.JsReport
{
    class TemplateOptions
    {
    }
}
